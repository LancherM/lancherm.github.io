$webfont.load("body", "f7187e8afbe04b5eb949cdae337b5de1", "jdzhonyuanjian");
/*$webfont.load("#id1,.class1,h1", "f7187e8afbe04b5eb949cdae337b5de1", "jdzhonyuanjian");*/
/*．．．*/
$webfont.draw();